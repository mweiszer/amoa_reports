All instances are in GM format. See http://www.asap.cs.nott.ac.uk/external/atr/benchmarks/index.shtml for information about the GM format.
